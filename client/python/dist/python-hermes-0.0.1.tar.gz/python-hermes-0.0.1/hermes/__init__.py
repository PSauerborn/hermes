# __init__.py

__version__ = '0.0.1'

from hermes.hermes import push_gauge, push_counter